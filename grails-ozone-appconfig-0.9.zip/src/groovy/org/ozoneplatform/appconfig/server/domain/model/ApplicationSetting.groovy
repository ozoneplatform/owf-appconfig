package org.ozoneplatform.appconfig.server.domain.model



public interface ApplicationSetting {

	String getCode()	

}

