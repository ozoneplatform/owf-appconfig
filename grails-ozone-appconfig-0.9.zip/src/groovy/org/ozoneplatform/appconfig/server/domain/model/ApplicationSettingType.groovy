package org.ozoneplatform.appconfig.server.domain.model



public interface ApplicationSettingType {

	String getDescription()

}

